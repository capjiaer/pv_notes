#!tvf
#      Note: This version does not produce old style encoding.

if {[catch {package require calibre_enc 1.6} err] == 1} {
    error "CALENC Loader error: $err\nThis Tcl file may have been encoded with a more recent version of calibre_enc/caltvfencrypt\nIn order to run on this version of Calibre, it must be encoded on the same or earlier version of Calibre."
}
calibre_enc::load {
CALENC 3
eAFLYWRk5AIAAgwAcgAAb
eAFTViwpS:MCAAWFAZ8Ac
eAEdzTEOwyAQRNHepxjJfU7hNknjPprABlYgIBgn1.fa7ZfmzTTPWKNu:GgW.DVn0HuMKGh0iUE8XBSXNox6Ze6jvhpHxI9d:bYZi0eX765dJvNaCncWm.bTYApyO.NS8XiuKGKkWS6yBDHyOj8AV2IuEgAAb
eAHLSdVT4OIqTi1RKEgsyYgvS8wpVlBSsbJKzSvTcHb08XQKco0PcA1yjg.wdo939nB19g7WVOJKyy9KTUzOgOtRUEHorubKSSwoSM1LUUgsLcmPB0kgpLlqubgKEpOzE9NTFYpSC0szi1IVCrLTfRMBubotsAAAb
eAHLS0xPLeLiAgAKWgIia
}
