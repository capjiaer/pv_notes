import argparse
import bisect

def parse_layers(layers):
    result = []
    for l in layers:
        if '.' in l:
            layer_num, datatype = l.split('.')
            result.append((layer_num, datatype))
        else:
            result.append((l, '0'))
    return result

def parse_voltage_map(map_list):
    voltage_map = {}
    voltage_keys = []
    for i in range(0, len(map_list), 2):
        key = map_list[i]
        value = map_list[i+1]
        # 转换 key 为 float 方便比较
        if key.startswith('0P'):
            v = float(key.replace('P', '.'))
        elif 'P' in key:
            v = float(key.replace('P', '.'))
        else:
            v = float(key)
        voltage_map[v] = (key, value)
        voltage_keys.append(v)
    voltage_keys.sort()
    return voltage_map, voltage_keys

def find_nearest_voltage(voltage, voltage_keys):
    pos = bisect.bisect_left(voltage_keys, voltage)
    if pos == 0:
        return voltage_keys[0]
    if pos == len(voltage_keys):
        return voltage_keys[-1]
    before = voltage_keys[pos - 1]
    after = voltage_keys[pos]
    if abs(voltage - before) <= abs(voltage - after):
        return before
    else:
        return after

def main():
    parser = argparse.ArgumentParser(description='生成 LAYOUT TEXT/POLYGON 文件')
    parser.add_argument('--min_voltage_layer', nargs='*', default=['69.97', '69.110'], help='min_voltage_layer, 格式如 11.10 12.33')
    parser.add_argument('--max_voltage_layer', nargs='*', default=['69.109', '69.98'], help='max_voltage_layer, 格式如 11.09 12.34')
    parser.add_argument('--text_layer', nargs='*', default=['69.20'], help='text_layer, 格式如 11.01 12')
    parser.add_argument('--voltage_mark_layer', nargs='*', default=[], help='voltage_mark_layer, 格式如 11.11 12.35')
    parser.add_argument('--esd_lable_layer', nargs='*', default=['69.60'], help='esd_lable_layer, 格式如 11.50 12.51')
    parser.add_argument('--voltage_datatype_map', nargs='*', default=['0P75','94','1P2','101','1P5','105','1P8','102','2P0','104','2P5','103','3P3','108'], help='电压到datatype的映射，如 0P75 94 1P2 101')
    parser.add_argument('--ratio', type=float, default=0.1, help='ratio')
    parser.add_argument('--cell_name', required=True, help='cell_name')
    parser.add_argument('--input_file', required=True, help='输入文件')
    parser.add_argument('--output_file', required=True, help='输出文件')
    args = parser.parse_args()

    min_layers = parse_layers(args.min_voltage_layer)
    max_layers = parse_layers(args.max_voltage_layer)
    text_layers = parse_layers(args.text_layer)
    mark_layers = parse_layers(args.voltage_mark_layer)
    esd_layers = parse_layers(args.esd_lable_layer)
    voltage_map, voltage_keys = parse_voltage_map(args.voltage_datatype_map)

    with open(args.input_file, 'r') as fin, open(args.output_file, 'w') as fout:
        # 输出参数说明
        if args.max_voltage_layer:
            fout.write('// max_voltage_layer ' + ' '.join(args.max_voltage_layer) + '\n')
        if args.min_voltage_layer:
            fout.write('// min_voltage_layer ' + ' '.join(args.min_voltage_layer) + '\n')
        if args.text_layer:
            fout.write('// text_layer ' + ' '.join(args.text_layer) + '\n')
        if args.voltage_mark_layer:
            fout.write('// voltage_mark_layer ' + ' '.join(args.voltage_mark_layer) + '\n')
        if args.esd_lable_layer:
            fout.write('// esd_lable_layer ' + ' '.join(args.esd_lable_layer) + '\n')
        if args.voltage_datatype_map:
            fout.write('// voltage_datatype_map ' + ' '.join(args.voltage_datatype_map) + '\n')
        fout.write(f'// ratio {args.ratio}\n')
        fout.write(f'// cell_name {args.cell_name}\n')
        fout.write(f'// input_file {args.input_file}\n')
        fout.write(f'// output_file {args.output_file}\n\n\n')

        for line in fin:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if len(parts) == 4:
                name, voltage, x, y = parts
                type_str = None
            elif len(parts) == 5:
                name, voltage, x, y, type_str = parts
            else:
                print(f"跳过格式错误行: {line}")
                continue
            voltage = float(voltage)
            x = float(x)
            y = float(y)

            # 输出分组注释
            if type_str:
                fout.write(f'// INFO: {name} {voltage} {x} {y} {type_str}\n')
            else:
                fout.write(f'// INFO: {name} {voltage} {x} {y}\n')

            # min_voltage_layer
            for layer_num, datatype in min_layers:
                fout.write(f'LAYOUT TEXT "0" {x} {y} {layer_num} {datatype} {args.cell_name} // min_voltage_layer\n')
            # max_voltage_layer
            for layer_num, datatype in max_layers:
                v = voltage * (1 + args.ratio)
                fout.write(f'LAYOUT TEXT "{v:.3f}" {x} {y} {layer_num} {datatype} {args.cell_name} // max_voltage_layer\n')
            # text_layer
            for layer_num, datatype in text_layers:
                fout.write(f'LAYOUT TEXT "{name}" {x} {y} {layer_num} {datatype} {args.cell_name} // text_layer\n')
            # voltage_mark_layer（优先用映射）
            if voltage_keys:
                nearest_v = find_nearest_voltage(voltage, voltage_keys)
                _, datatype = voltage_map[nearest_v]
                layer_num = '69'
                fout.write(f'LAYOUT POLYGON 2 {x-0.001:.3f} {y-0.001:.3f} {x+0.001:.3f} {y+0.001:.3f} {layer_num} {datatype} {args.cell_name} // voltage_mark_layer\n')
            else:
                for layer_num, datatype in mark_layers:
                    x0 = x - 0.001
                    y0 = y - 0.001
                    x1 = x + 0.001
                    y1 = y + 0.001
                    fout.write(f'LAYOUT POLYGON 2 {x0:.3f} {y0:.3f} {x1:.3f} {y1:.3f} {layer_num} {datatype} {args.cell_name} // voltage_mark_layer\n')
            # esd_lable_layer
            if type_str and esd_layers:
                if type_str.upper() in ["POWER", "GROUND"]:
                    for layer_num, datatype in esd_layers:
                        fout.write(f'LAYOUT TEXT "POWER_ESD" {x} {y} {layer_num} {datatype} {args.cell_name} // {type_str.upper()}\n')
                elif type_str.upper() == "SIGNAL":
                    for layer_num, datatype in esd_layers:
                        fout.write(f'LAYOUT TEXT "FULL_ESD" {x} {y} {layer_num} {datatype} {args.cell_name} // SIGNAL\n')

if __name__ == '__main__':
    main()
