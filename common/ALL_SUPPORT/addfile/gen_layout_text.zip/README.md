# PV Info Layout Generator

本项目用于根据输入的电压、坐标等信息，自动生成 LAYOUT TEXT/POLYGON 文件，适用于版图设计自动化。

## 文件说明
- `gen_layout_text.py`：主程序脚本。
- `test_input.txt`：示例输入文件。
- `test_output.txt`：示例输出文件。

## 依赖环境
- Python 3.x

## 使用方法

```bash
python gen_layout_text.py \
  --cell_name <单元名> \
  --input_file <输入文件路径> \
  --output_file <输出文件路径> \
  [--min_voltage_layer LAYER ...] \
  [--max_voltage_layer LAYER ...] \
  [--text_layer LAYER ...] \
  [--voltage_mark_layer LAYER ...] \
  [--esd_lable_layer LAYER ...] \
  [--voltage_datatype_map MAP ...] \
  [--ratio RATIO]
```

### 参数说明
- `--cell_name`：必选，单元名称。
- `--input_file`：必选，输入文件路径。
- `--output_file`：必选，输出文件路径。
- `--min_voltage_layer`：可选，最小电压层，格式如 `69.97 69.110`。
- `--max_voltage_layer`：可选，最大电压层，格式如 `69.109 69.98`。
- `--text_layer`：可选，文本层，格式如 `69.20`。
- `--voltage_mark_layer`：可选，电压标记层，格式如 `69.30`。
- `--esd_lable_layer`：可选，ESD标签层，格式如 `69.60`。
- `--voltage_datatype_map`：可选，电压到datatype的映射，如 `0P75 94 1P2 101`。
- `--ratio`：可选，最大电压层电压的放大比例，默认0.1。

### 输入文件格式
每行格式如下：
```
name voltage x y [type]
```
- `name`：节点名称
- `voltage`：电压值（浮点数）
- `x`、`y`：坐标（浮点数）
- `type`：可选，类型（如 POWER、GROUND、SIGNAL）

示例：
```
VDD1 1.8 10.0 20.0 POWER
VSS1 0.0 15.0 25.0 GROUND
SIG1 1.2 20.0 30.0 SIGNAL
VDD2 3.3 25.0 35.0 POWER
```

### 输出文件
输出文件为标准的 LAYOUT TEXT/POLYGON 格式，包含注释和各类标记。

## 示例
运行示例：
```bash
python gen_layout_text.py --cell_name TEST_CELL --input_file test_input.txt --output_file test_output.txt
```

## 联系方式
如有问题请联系作者。
 